/**
	@author Joo Yong Sung
	@version 1.0
	<h2> This class is not for Run-Time but for making  Document</h2>
*/
public class DocsComment {
	
	/**
	@param num1 num1 is first number
	@param num2 num2 is second number
	@return return plusing num1 and num2
            */
	public int getTotal(int num1, int num2)
	{
		return num1 + num2;
	}

}